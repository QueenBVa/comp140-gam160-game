# Quick Start

1. Provide an audio clip to the AudioSource component on the FFT Source gameobject for this to work.
2. Once an audio clip is put in the `Audio Clip` field, run the scene.