﻿using UnityEngine;
using System.Collections;

public class QuitButton : MonoBehaviour 
{
	public void OnClick()
	{
		Application.Quit (); //When the Quit button is clicked, the game will exit and close.
	}
}