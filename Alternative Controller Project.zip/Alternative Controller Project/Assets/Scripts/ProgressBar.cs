﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class ProgressBar : MonoBehaviour
{
    public EndGame endGame;
    public Slider progressBar;
    public GameObject lightObject;
    LightControl lightControl;
    public float barValue;
    bool lightOnOff
    {
        get
        {
            if (lightControl != null)
            {
                return lightControl._light.enabled;
            }
            return false;
        }
    }

    void Start ()
    {
        lightObject = GameObject.FindGameObjectWithTag("Light");
        lightControl = lightObject.GetComponent<LightControl>();

	}
	
	void Update ()
    {
        if (!lightOnOff)
        {
            progressBar.value += barValue * Time.deltaTime;
        }

        if (lightOnOff)
        {
            progressBar.value += (barValue * 2) * Time.deltaTime;
        }

        if(progressBar.value >= 100)
        {
            endGame.Win();
        }
	}
}