﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class ProgressBar : MonoBehaviour
{
    public Slider progressBar;
    public GameObject lightObject;
    LightControl lightControl;
    bool lightOnOff
    {
        get
        {
            if (lightControl != null)
            {
                return lightControl._light.enabled;
            }
            return false;
        }
    }

    void Start ()
    {
        lightObject = GameObject.FindGameObjectWithTag("Light");
        lightControl = lightObject.GetComponent<LightControl>();

	}
	
	void Update ()
    {
        if (!lightOnOff)
        {
            progressBar.value += 0.5f * Time.deltaTime;
        }

        if (lightOnOff)
        {
            progressBar.value += 1 * Time.deltaTime;
        }
	}
}
