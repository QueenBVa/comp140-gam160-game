﻿using UnityEngine;
using System.Collections;

public class EnemyAI : MonoBehaviour
{
    public NavMeshAgent navAgent;
    public Transform target;
    LightControl lightControl;
    bool lightOnOff
    {
        get
        {
            if(lightControl != null)
            {
                return lightControl._light.enabled;
            }
            return false;
        }
    }
    public GameObject player;
    public GameObject lightObject;

	void Start ()
    {
        lightObject = GameObject.FindGameObjectWithTag("Light");
        lightControl = lightObject.GetComponent<LightControl>();
	}
	
	void Update ()
    {
        if (lightOnOff)
        {
            navAgent.SetDestination(target.position);
        }

        if (!lightOnOff)
        {
            navAgent.SetDestination(player.transform.position);
        }
    }
}
