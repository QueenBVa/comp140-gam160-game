﻿using UnityEngine;
using System.Collections;

public class EnemyAI : MonoBehaviour
{
    public NavMeshAgent navAgent;
    public Transform target;
    LightControl lightControl;
    bool lightOnOff
    {
        get
        {
            if(lightControl != null)
            {
                return lightControl._light.enabled;
            }
            return false;
        }
    }
    public GameObject player;
    public GameObject lightObject;

	void Start ()
    {
        lightObject = GameObject.FindGameObjectWithTag("Light");
        lightControl = lightObject.GetComponent<LightControl>();
	}
	
	void Update ()
    {
        if (lightOnOff)
        {
            Debug.Log("Light on");
            navAgent.SetDestination(target.position);
        }

        if (!lightOnOff)
        {
            Debug.Log("Light off");
            navAgent.SetDestination(player.transform.position);
        }
    }
}
