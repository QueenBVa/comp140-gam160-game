﻿using UnityEngine;
using System.Collections;

public class PatrolTriggerScript : MonoBehaviour
{
    public Transform insideTarget;
    public GameObject lightObject;
    LightControl lightControl;
    bool lightOnOff
    {
        get
        {
            if (lightControl != null)
            {
                return lightControl._light.enabled;
            }
            return false;
        }
    }

    void Start()
    {
        lightObject = GameObject.FindGameObjectWithTag("Light");
        lightControl = lightObject.GetComponent<LightControl>();

    }

    void OnTriggerEnter(Collider other)
    {
        if (lightOnOff)
        {
            other.gameObject.transform.parent.gameObject.GetComponent<PatrollingEnemy>().enabled = false;
            other.gameObject.transform.parent.gameObject.GetComponent<NavMeshAgent>().SetDestination(insideTarget.position);
        }
    }
}
