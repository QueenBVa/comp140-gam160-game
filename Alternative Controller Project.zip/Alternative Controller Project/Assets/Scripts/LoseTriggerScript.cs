﻿using UnityEngine;
using System.Collections;

public class LoseTriggerScript : MonoBehaviour {

    public EndGame endGame;
    public string enemyTag;

	void OnTriggerEnter(Collider other)
    {
        if(other.tag == enemyTag)
        {
            endGame.Lose();
        }
    }
}
