﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class SceneChange : MonoBehaviour 
{
	public string nextScene;
	public void OnClick ()
	{
		SceneManager.LoadScene (nextScene);
	}
}