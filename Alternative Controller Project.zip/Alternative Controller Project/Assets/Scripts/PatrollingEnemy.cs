﻿using UnityEngine;
using System.Collections;

public class PatrollingEnemy : MonoBehaviour
{
    private NavMeshAgent agent;
    public Transform[] target;
    int targetId = 0;
    float dist = 0;

    void Start ()
    {
        agent = GetComponent<NavMeshAgent>();
    }
	
	void Update ()
    {
        dist = Vector3.Distance(transform.position, target[targetId].position); //Finds the distance between the enemy and the next object it will travel towards on a path.

        if (dist < 1)
        {
            if (targetId < target.Length - 1)
            {
                targetId++; //Checks if the index number of the target is less than the last index in the array, and adds 1 to it if it is...
            }

            else
            {
                targetId = 0; //... Otherwise, it sets the index to 0 if it is the last inddex in the array.
            }
        }
        agent.SetDestination(target[targetId].position);
    }
}
