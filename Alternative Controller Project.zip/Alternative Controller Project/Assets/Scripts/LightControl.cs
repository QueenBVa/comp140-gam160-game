﻿using UnityEngine;
using System.Collections;
using System.IO.Ports;
using System;

public class LightControl : MonoBehaviour
{
    public Light _light;
    public string COMPort = "COM4";
    SerialPort serialPort;

    void Start()
    {
        serialPort = new SerialPort();
        serialPort.PortName = COMPort;
        serialPort.Parity = Parity.None;
        serialPort.BaudRate = 9600;
        serialPort.DataBits = 8;
        serialPort.StopBits = StopBits.One;
        serialPort.Open();

        InvokeRepeating("ReadArduino", 0f, 0.5f);
    }

    void Update ()
    {
        

        if (Input.GetKeyDown(KeyCode.Space))
        {
            _light.enabled = !_light.enabled;
        }
    }

    void OnApplicationQuit()
    {
        serialPort.Close();
    }

    void ReadArduino()
    {
        string data = serialPort.ReadLine();

        Debug.Log("Data from Arduino " + data);

        if (data.Equals("1"))
        {
            _light.enabled = true;
        }

        else
        {
            _light.enabled = false;
        }
        serialPort.BaseStream.Flush();
    }
}
