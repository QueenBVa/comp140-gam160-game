﻿using UnityEngine;
using System.Collections;

public class LightControl : MonoBehaviour
{
    public Light _light;

	void Update ()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            _light.enabled = !_light.enabled;
        }
    }
}
